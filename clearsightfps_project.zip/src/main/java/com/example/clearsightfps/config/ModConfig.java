package com.example.clearsightfps.config;

public class ModConfig {
    public static boolean disableParticles = true;
    public static boolean redCrosshair = true;
}
