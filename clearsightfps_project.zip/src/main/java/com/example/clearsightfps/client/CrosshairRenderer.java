package com.example.clearsightfps.client;

import com.example.clearsightfps.config.ModConfig;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.hit.EntityHitResult;

public class CrosshairRenderer {
    public static void init() {
        HudRenderCallback.EVENT.register((drawContext, tickDelta) -> {
            if (!ModConfig.redCrosshair) return;
            MinecraftClient client = MinecraftClient.getInstance();
            if (client.crosshairTarget instanceof EntityHitResult hit) {
                Entity entity = hit.getEntity();
                if (entity instanceof LivingEntity) {
                    int x = drawContext.getScaledWindowWidth() / 2;
                    int y = drawContext.getScaledWindowHeight() / 2;
                    drawContext.fill(x - 2, y - 2, x + 2, y + 2, 0xFFFF0000);
                }
            }
        });
    }
}
