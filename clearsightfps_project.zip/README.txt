ClearSightFPS – Fabric Mod (1.21+)

After uploading this project to GitHub and opening Codespaces:
1. Open terminal
2. Run: gradle wrapper
3. Run: chmod +x gradlew
4. Run: ./gradlew build

Output JAR: build/libs/
